# Código-fonte público do 3105

Esta pasta contém uma cópia organizada, sem histórico Git, do repositório público **YangJiiii/3105**.

| Campo | Informação |
|---|---|
| Repositório de origem | https://github.com/YangJiiii/3105 |
| Referência copiada | `v1.0.1` / commit público `90ab4dd` |
| Licença incluída | GNU General Public License v3.0 (`LICENSE`) |
| Preparada em | 16 de agosto de 2026 |

O arquivo `LICENSE` original foi preservado. Caso esta base seja modificada e distribuída, devem ser respeitadas as obrigações da GPL-3.0, incluindo a preservação da licença e a disponibilização do código-fonte correspondente.

O conteúdo foi apenas copiado e organizado para arquivamento. Nenhum binário, certificado, perfil de provisionamento ou componente da GoPlay foi incluído.

## Referências

[1]: https://github.com/YangJiiii/3105 "YangJiiii/3105 — repositório público"
[2]: https://www.gnu.org/licenses/gpl-3.0.html "GNU General Public License v3.0"
