import SwiftUI

struct RemoteCommandsView: View {
    @State private var hsEnabled = false
    @State private var hologramEnabled = false
    @State private var speedEnabled = false
    @State private var isLoading: [String: Bool] = [:]
    @State private var statusMessage = ""
    @State private var userKey = ""
    @State private var isConnected = false

    private let apiBase = "http://169.58.158.100:10043"
    private let apiKey = "68ad4946e572dad9b7eabd92bd55cf3a66848b9f6bfcef17badb6031ebfd7816"

    var body: some View {
        NavigationView {
            List {
                connectionSection
                if isConnected {
                    commandsSection
                    statusSection
                }
            }
            .navigationTitle("Comandos")
            .listStyle(.insetGrouped)
        }
    }

    private var connectionSection: some View {
        Section {
            HStack {
                Image(systemName: isConnected ? "wifi" : "wifi.slash")
                    .foregroundColor(isConnected ? .green : .red)
                    .font(.title2)
                VStack(alignment: .leading, spacing: 4) {
                    Text(isConnected ? "Conectado" : "Desconectado")
                        .font(.headline)
                    Text(isConnected ? "Servidor online" : "Insira sua chave")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Spacer()
            }
            .padding(.vertical, 4)

            if !isConnected {
                TextField("Chave de acesso", text: $userKey)
                    .textFieldStyle(.roundedBorder)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)

                Button(action: connectToServer) {
                    HStack {
                        Spacer()
                        if isLoading["connect"] == true {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        } else {
                            Text("Conectar")
                                .fontWeight(.semibold)
                        }
                        Spacer()
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(.blue)
                .disabled(userKey.isEmpty || isLoading["connect"] == true)
            }
        } header: {
            Text("Servidor")
        }
    }

    private var commandsSection: some View {
        Section {
            CommandToggleRow(
                title: "Head Shot",
                subtitle: "Mira automática na cabeça",
                icon: "scope",
                isOn: $hsEnabled,
                isLoading: isLoading["hs"] ?? false
            ) {
                toggleCommand("hs", enabled: !hsEnabled)
            }

            CommandToggleRow(
                title: "Holograma",
                subtitle: "Visualização de inimigos",
                icon: "eye.fill",
                isOn: $hologramEnabled,
                isLoading: isLoading["hologram"] ?? false
            ) {
                toggleCommand("hologram", enabled: !hologramEnabled)
            }

            CommandToggleRow(
                title: "Speed",
                subtitle: "Velocidade aumentada",
                icon: "hare.fill",
                isOn: $speedEnabled,
                isLoading: isLoading["speed"] ?? false
            ) {
                toggleCommand("speed", enabled: !speedEnabled)
            }
        } header: {
            Text("Comandos Ativos")
        }
    }

    private var statusSection: some View {
        Section {
            if !statusMessage.isEmpty {
                HStack {
                    Image(systemName: "info.circle")
                        .foregroundColor(.blue)
                    Text(statusMessage)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            Button(action: disconnect) {
                HStack {
                    Spacer()
                    Text("Desconectar")
                        .foregroundColor(.red)
                    Spacer()
                }
            }
        } header: {
            Text("Status")
        }
    }

    // MARK: - Actions

    private func connectToServer() {
        isLoading["connect"] = true
        statusMessage = ""

        let urlString = "\(apiBase)/\(apiKey)/check?key=\(userKey)"
        guard let url = URL(string: urlString) else {
            statusMessage = "URL inválida"
            isLoading["connect"] = false
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                isLoading["connect"] = false
                if let error = error {
                    statusMessage = "Erro: \(error.localizedDescription)"
                    return
                }
                guard let httpResponse = response as? HTTPURLResponse else {
                    statusMessage = "Sem resposta do servidor"
                    return
                }
                if httpResponse.statusCode == 200 {
                    isConnected = true
                    statusMessage = "Conectado com sucesso"
                } else {
                    statusMessage = "Chave inválida ou expirada"
                }
            }
        }.resume()
    }

    private func toggleCommand(_ command: String, enabled: Bool) {
        isLoading[command] = true
        statusMessage = ""

        let action = enabled ? "on" : "off"
        let urlString = "\(apiBase)/\(apiKey)/command?key=\(userKey)&cmd=\(command)&action=\(action)"
        guard let url = URL(string: urlString) else {
            isLoading[command] = false
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                isLoading[command] = false
                if let error = error {
                    statusMessage = "Erro: \(error.localizedDescription)"
                    return
                }
                guard let httpResponse = response as? HTTPURLResponse,
                      httpResponse.statusCode == 200 else {
                    statusMessage = "Falha ao enviar comando"
                    return
                }
                switch command {
                case "hs": hsEnabled = enabled
                case "hologram": hologramEnabled = enabled
                case "speed": speedEnabled = enabled
                default: break
                }
                statusMessage = "\(command.uppercased()) \(enabled ? "ativado" : "desativado")"
            }
        }.resume()
    }

    private func disconnect() {
        isConnected = false
        hsEnabled = false
        hologramEnabled = false
        speedEnabled = false
        userKey = ""
        statusMessage = ""
    }
}

struct CommandToggleRow: View {
    let title: String
    let subtitle: String
    let icon: String
    @Binding var isOn: Bool
    let isLoading: Bool
    let action: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(isOn ? .green : .gray)
                .frame(width: 32)

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.body)
                    .fontWeight(.medium)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Spacer()

            if isLoading {
                ProgressView()
            } else {
                Toggle("", isOn: Binding(
                    get: { isOn },
                    set: { _ in action() }
                ))
                .labelsHidden()
            }
        }
        .padding(.vertical, 4)
    }
}
