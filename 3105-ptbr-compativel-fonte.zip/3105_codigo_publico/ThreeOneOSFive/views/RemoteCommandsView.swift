import SwiftUI

struct RemoteCommandsView: View {
    @AppStorage("userLicenseKey") private var licenseKey: String = ""
    @State private var headshot: Bool = false
    @State private var holograma: Bool = false
    @State private var speed: Bool = false
    @State private var isLoading: Bool = false
    @State private var statusMessage: String = ""
    @State private var isConnected: Bool = false

    private let apiBase = "http://169.58.158.100:10043"
    private let apiKey = "68ad4946e572dad9b7eabd92bd55cf3a66848b9f6bfcef17badb6031ebfd7816"

    var body: some View {
        List {
            Section(header: Text("CHAVE DE ACESSO")) {
                HStack {
                    TextField("Insira sua chave", text: $licenseKey)
                        .textFieldStyle(.plain)
                        .autocapitalization(.allCharacters)
                        .disableAutocorrection(true)
                    Button(action: connectAndLoad) {
                        if isLoading {
                            ProgressView()
                        } else {
                            Image(systemName: "arrow.clockwise.circle.fill")
                                .font(.title2)
                                .foregroundColor(.blue)
                        }
                    }
                    .disabled(licenseKey.isEmpty || isLoading)
                }
            }

            if isConnected {
                Section(header: Text("COMANDOS")) {
                    Toggle(isOn: Binding(
                        get: { headshot },
                        set: { newVal in sendCommand(action: "headshot", state: newVal) }
                    )) {
                        Label("Head Shot", systemImage: "scope")
                    }
                    .tint(.red)

                    Toggle(isOn: Binding(
                        get: { holograma },
                        set: { newVal in sendCommand(action: "holograma", state: newVal) }
                    )) {
                        Label("Holograma", systemImage: "person.2.fill")
                    }
                    .tint(.purple)

                    Toggle(isOn: Binding(
                        get: { speed },
                        set: { newVal in sendCommand(action: "speed", state: newVal) }
                    )) {
                        Label("Speed", systemImage: "hare.fill")
                    }
                    .tint(.green)
                }

                Section {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                        Text("Conectado")
                            .foregroundColor(.green)
                        Spacer()
                        Text(licenseKey.prefix(12) + "...")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }

            if !statusMessage.isEmpty {
                Section {
                    Text(statusMessage)
                        .font(.caption)
                        .foregroundColor(isConnected ? .secondary : .red)
                }
            }
        }
        .navigationTitle("Comandos")
        .onAppear {
            if !licenseKey.isEmpty {
                connectAndLoad()
            }
        }
    }

    private func connectAndLoad() {
        guard !licenseKey.isEmpty else { return }
        isLoading = true
        statusMessage = ""
        let key = licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        let urlStr = "\(apiBase)/\(apiKey)/command/status?key=\(key)"
        guard let url = URL(string: urlStr) else {
            statusMessage = "URL inválida"
            isLoading = false
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                isLoading = false
                if let error = error {
                    statusMessage = "Erro: \(error.localizedDescription)"
                    isConnected = false
                    return
                }
                guard let data = data,
                      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let success = json["success"] as? Bool, success else {
                    statusMessage = "Chave inválida ou expirada"
                    isConnected = false
                    return
                }
                isConnected = true
                if let commands = json["commands"] as? [String: Any] {
                    if let hs = commands["headshot"] as? [String: Any] {
                        headshot = (hs["state"] as? String) == "on"
                    }
                    if let holo = commands["holograma"] as? [String: Any] {
                        holograma = (holo["state"] as? String) == "on"
                    }
                    if let sp = commands["speed"] as? [String: Any] {
                        speed = (sp["state"] as? String) == "on"
                    }
                }
                statusMessage = ""
            }
        }.resume()
    }

    private func sendCommand(action: String, state: Bool) {
        let key = licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        let stateStr = state ? "on" : "off"
        let urlStr = "\(apiBase)/\(apiKey)/command?key=\(key)&action=\(action)&state=\(stateStr)"
        guard let url = URL(string: urlStr) else { return }

        // Update local state immediately
        switch action {
        case "headshot": headshot = state
        case "holograma": holograma = state
        case "speed": speed = state
        default: break
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            DispatchQueue.main.async {
                if error != nil {
                    // Revert on failure
                    switch action {
                    case "headshot": headshot = !state
                    case "holograma": holograma = !state
                    case "speed": speed = !state
                    default: break
                    }
                    statusMessage = "Falha ao enviar comando"
                }
            }
        }.resume()
    }
}
