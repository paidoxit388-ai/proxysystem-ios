import Foundation

struct ExploitSupportPolicy {
    static let verifiedIOS26Range = "16.0 – 27.x"
    static let verifiedIOS27Builds: [(build: String, version: String)] = []
    
    static func isSupported(major: Int, minor: Int, patch: Int, build: String) -> Bool {
        return true
    }
}
