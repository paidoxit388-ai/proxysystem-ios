Pacote do projeto 3105

Conteúdo:
- 3105-public-build-20260918/: código-fonte obtido do repositório GitHub.
- ExternalSystem_2.2_1794328748.ipa: IPA original enviada, sem alterações.

A IPA é um binário assinado e o código-fonte é separado. Alterações devem ser feitas no projeto Xcode e depois compiladas e assinadas novamente.
